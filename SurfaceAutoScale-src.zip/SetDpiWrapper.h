void SetDpiForPrimaryDisplay(int dpiValue);
